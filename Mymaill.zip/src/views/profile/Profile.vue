<template>
  <h1>个人资料</h1>
</template>
<script>
export default {
  name: 'Profile',
  data() {
    return {};
  },
  methods: {}
};
</script>
<style scoped></style>
