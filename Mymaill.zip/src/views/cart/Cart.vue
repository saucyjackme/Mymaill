<template>
  <h1>购物车</h1>
</template>
<script>
export default {
  name: 'Cart',
  data() {
    return {};
  },
  methods: {}
};
</script>
<style scoped></style>
