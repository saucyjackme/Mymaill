<template>
  <div class="wrapper" ref="wrapper">
    <div class="content">
      <slot></slot>
    </div>
  </div>
</template>
<script>
import BScroll from 'better-scroll'
import ObserveDOM from "@better-scroll/observe-dom";
import ObserveImage from '@better-scroll/observe-image';

BScroll.use(ObserveDOM);
BScroll.use(ObserveImage);

export default {
  name: "Scroll",
  data() {
    return {
      bscroll:null
    };
  },
  mounted() {
    this.bscroll = new BScroll(this.$refs.wrapper, {
      click:true,
      scrollX: false,
      scrollY: true,
      observeDOM: true,
      observeImage:true
    });
  },
  methods: {},
};
</script>
<style scoped></style>
